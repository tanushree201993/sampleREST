package com.unity.UnitySpringBootJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;


@SpringBootConfiguration
@EntityScan(basePackages  = {"com.unity.demo.model"})
@EnableAutoConfiguration
@EnableJpaRepositories(basePackages = "com.unity.demo.dao")
@SpringBootApplication(scanBasePackages={"com.unity.demo.*"})
public class UnitySpringBootJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnitySpringBootJpaApplication.class, args);
	}

}


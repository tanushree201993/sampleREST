package com.unity.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.unity.demo.dao.UnityDao;
import com.unity.demo.model.Employee;

@Service
public class UnityServiceImpl implements UnityService{
	@Autowired
	private UnityDao unityDao;

	public List<Employee> getEmployee() {
		return unityDao.findAll();
	}

	public String createEmployee(List<Employee> employee) {
		unityDao.saveAll(employee);
		return employee.get(1).getName();
	}

}

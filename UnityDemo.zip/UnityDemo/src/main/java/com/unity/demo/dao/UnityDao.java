package com.unity.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.unity.demo.model.Employee;

@Repository
public interface UnityDao extends JpaRepository<Employee, Integer>{

}

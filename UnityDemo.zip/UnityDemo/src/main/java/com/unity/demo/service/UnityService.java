package com.unity.demo.service;

import java.util.List;

import com.unity.demo.model.Employee;


public interface UnityService {

	public List<Employee> getEmployee();

	public String createEmployee(List<Employee> employee);

}
